import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/services/weather_background_task.dart';
import 'presentation/providers/app_providers.dart';
import 'presentation/screens/weather_home_screen.dart';
import 'core/theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('fa_IR');
  final preferences = await SharedPreferences.getInstance();

  // WorkManager is best-effort: Android controls exact execution time and may
  // defer periodic work while Doze or battery restrictions are active.
  try {
    await configureWeatherBackgroundRefresh();
  } catch (_) {
    // The foreground application remains usable if background scheduling fails.
  }

  runApp(
    ProviderScope(
      overrides: [sharedPreferencesProvider.overrideWithValue(preferences)],
      child: const WeatherGlassApp(),
    ),
  );
}

class WeatherGlassApp extends StatelessWidget {
  const WeatherGlassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'هواشناسی',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR'), Locale('en', 'US')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: WeatherHomeScreen(),
      ),
    );
  }
}
