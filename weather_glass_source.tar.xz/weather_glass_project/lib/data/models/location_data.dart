class Coordinates {
  const Coordinates({required this.latitude, required this.longitude});

  final double latitude;
  final double longitude;
}

enum LocationIssue {
  none,
  gpsDisabled,
  permissionDenied,
  permissionDeniedForever,
  unavailable,
}

class LocationResult {
  const LocationResult({required this.coordinates, this.issue = LocationIssue.none});

  final Coordinates? coordinates;
  final LocationIssue issue;
}
