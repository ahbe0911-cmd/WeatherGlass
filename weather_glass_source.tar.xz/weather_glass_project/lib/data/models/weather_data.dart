import 'weather_condition.dart';

class WeatherData {
  const WeatherData({
    required this.location,
    required this.current,
    required this.hourly,
    required this.daily,
  });

  final WeatherLocation location;
  final CurrentWeather current;
  final List<HourlyForecast> hourly;
  final List<DailyForecast> daily;

  factory WeatherData.fromJson(Map<String, dynamic> json) {
    final currentJson = _asMap(json['current']);
    final hourlyJson = _asMap(json['hourly']);
    final dailyJson = _asMap(json['daily']);

    final hourlyTimes = _asList(hourlyJson['time']);
    final currentTime = _asString(currentJson['time']);
    final currentDateTime = DateTime.tryParse(currentTime);
    final allHours = <HourlyForecast>[];
    for (var index = 0; index < hourlyTimes.length; index++) {
      final hour = HourlyForecast.fromOpenMeteo(hourlyJson, index);
      final hourDateTime = DateTime.tryParse(hour.time);
      if (hourDateTime == null || currentDateTime == null || !hourDateTime.isBefore(currentDateTime)) {
        allHours.add(hour);
      }
    }

    final uvIndex = allHours.isNotEmpty ? allHours.first.uv : 0.0;
    final dailyTimes = _asList(dailyJson['time']);
    final daily = List<DailyForecast>.generate(
      dailyTimes.length,
      (index) => DailyForecast.fromOpenMeteo(dailyJson, index),
      growable: false,
    );

    final timezone = _asString(json['timezone']);
    final current = CurrentWeather.fromOpenMeteo(currentJson, uvIndex: uvIndex);

    return WeatherData(
      location: WeatherLocation(
        name: 'موقعیت فعلی',
        region: '',
        country: '',
        localtime: currentTime.replaceAll('T', ' '),
        timezone: timezone,
      ),
      current: current,
      hourly: allHours.take(48).toList(growable: false),
      daily: daily.take(7).toList(growable: false),
    );
  }
}

class WeatherLocation {
  const WeatherLocation({
    required this.name,
    required this.region,
    required this.country,
    required this.localtime,
    this.timezone = '',
  });

  final String name;
  final String region;
  final String country;
  final String localtime;
  final String timezone;
}

class CurrentWeather {
  const CurrentWeather({
    required this.temperatureC,
    required this.feelsLikeC,
    required this.humidity,
    required this.windKph,
    required this.uv,
    required this.isDay,
    required this.lastUpdatedEpoch,
    required this.condition,
  });

  final double temperatureC;
  final double feelsLikeC;
  final int humidity;
  final double windKph;
  final double uv;
  final bool isDay;
  final int lastUpdatedEpoch;
  final WeatherCondition condition;

  factory CurrentWeather.fromOpenMeteo(
    Map<String, dynamic> json, {
    required double uvIndex,
  }) {
    final time = _asString(json['time']);
    return CurrentWeather(
      temperatureC: _asDouble(json['temperature_2m']),
      feelsLikeC: _asDouble(json['apparent_temperature']),
      humidity: _asInt(json['relative_humidity_2m']),
      windKph: _asDouble(json['wind_speed_10m']),
      uv: uvIndex,
      isDay: _asInt(json['is_day']) == 1,
      lastUpdatedEpoch: (DateTime.tryParse(time)?.millisecondsSinceEpoch ?? 0) ~/ 1000,
      condition: WeatherCondition.fromCode(_asInt(json['weather_code'])),
    );
  }
}

class HourlyForecast {
  const HourlyForecast({
    required this.timeEpoch,
    required this.time,
    required this.temperatureC,
    required this.feelsLikeC,
    required this.humidity,
    required this.windKph,
    required this.chanceOfRain,
    required this.isDay,
    required this.condition,
    this.uv = 0,
  });

  final int timeEpoch;
  final String time;
  final double temperatureC;
  final double feelsLikeC;
  final int humidity;
  final double windKph;
  final int chanceOfRain;
  final bool isDay;
  final WeatherCondition condition;
  final double uv;

  factory HourlyForecast.fromOpenMeteo(Map<String, dynamic> json, int index) {
    final time = _listString(json['time'], index);
    final parsedTime = DateTime.tryParse(time);
    return HourlyForecast(
      timeEpoch: (parsedTime?.millisecondsSinceEpoch ?? 0) ~/ 1000,
      time: time.replaceAll('T', ' '),
      temperatureC: _listDouble(json['temperature_2m'], index),
      feelsLikeC: _listDouble(json['apparent_temperature'], index),
      humidity: _listInt(json['relative_humidity_2m'], index),
      windKph: _listDouble(json['wind_speed_10m'], index),
      chanceOfRain: _listInt(json['precipitation_probability'], index),
      isDay: _listInt(json['is_day'], index) == 1,
      condition: WeatherCondition.fromCode(_listInt(json['weather_code'], index)),
      uv: _listDouble(json['uv_index'], index),
    );
  }
}

class DailyForecast {
  const DailyForecast({
    required this.date,
    required this.maxTemperatureC,
    required this.minTemperatureC,
    required this.averageHumidity,
    required this.maxWindKph,
    required this.uv,
    required this.chanceOfRain,
    required this.condition,
    required this.sunrise,
    required this.sunset,
  });

  final DateTime date;
  final double maxTemperatureC;
  final double minTemperatureC;
  final int averageHumidity;
  final double maxWindKph;
  final double uv;
  final int chanceOfRain;
  final WeatherCondition condition;
  final String sunrise;
  final String sunset;

  factory DailyForecast.fromOpenMeteo(Map<String, dynamic> json, int index) {
    final date = DateTime.tryParse(_listString(json['time'], index)) ?? DateTime.now();
    return DailyForecast(
      date: date,
      maxTemperatureC: _listDouble(json['temperature_2m_max'], index),
      minTemperatureC: _listDouble(json['temperature_2m_min'], index),
      averageHumidity: 0,
      maxWindKph: _listDouble(json['wind_speed_10m_max'], index),
      uv: _listDouble(json['uv_index_max'], index),
      chanceOfRain: _listInt(json['precipitation_probability_max'], index),
      condition: WeatherCondition.fromCode(_listInt(json['weather_code'], index)),
      sunrise: _clockOnly(_listString(json['sunrise'], index)),
      sunset: _clockOnly(_listString(json['sunset'], index)),
    );
  }
}

Map<String, dynamic> _asMap(Object? value) =>
    value is Map<String, dynamic> ? value : const <String, dynamic>{};

List<dynamic> _asList(Object? value) => value is List<dynamic> ? value : const [];

String _asString(Object? value) => value is String ? value : '';

double _asDouble(Object? value) => value is num ? value.toDouble() : 0;

int _asInt(Object? value) => value is num ? value.round() : 0;

String _listString(Object? value, int index) {
  final list = _asList(value);
  if (index >= list.length) return '';
  return _asString(list[index]);
}

double _listDouble(Object? value, int index) {
  final list = _asList(value);
  if (index >= list.length) return 0;
  return _asDouble(list[index]);
}

int _listInt(Object? value, int index) {
  final list = _asList(value);
  if (index >= list.length) return 0;
  return _asInt(list[index]);
}

String _clockOnly(String isoTime) {
  final separator = isoTime.indexOf('T');
  if (separator < 0) return '--:--';
  final time = isoTime.substring(separator + 1);
  return time.length >= 5 ? time.substring(0, 5) : '--:--';
}
