import 'package:flutter/material.dart';

enum WeatherKind { clear, cloudy, rain, snow, storm, fog }

class WeatherCondition {
  const WeatherCondition({required this.kind, required this.text, required this.code});

  final WeatherKind kind;
  final String text;
  final int code;

  String get animationAsset => switch (kind) {
        WeatherKind.clear => 'assets/animations/sunny.json',
        WeatherKind.cloudy => 'assets/animations/cloudy.json',
        WeatherKind.rain => 'assets/animations/rainy.json',
        WeatherKind.snow => 'assets/animations/snowy.json',
        WeatherKind.storm => 'assets/animations/stormy.json',
        WeatherKind.fog => 'assets/animations/foggy.json',
      };

  IconData get icon => switch (kind) {
        WeatherKind.clear => Icons.wb_sunny_rounded,
        WeatherKind.cloudy => Icons.cloud_rounded,
        WeatherKind.rain => Icons.grain_rounded,
        WeatherKind.snow => Icons.ac_unit_rounded,
        WeatherKind.storm => Icons.thunderstorm_rounded,
        WeatherKind.fog => Icons.blur_on_rounded,
      };

  /// Maps World Meteorological Organization (WMO) weather interpretation codes.
  static WeatherCondition fromCode(int code, {String? apiText}) {
    final kind = _kindFromCode(code);
    final text = apiText?.trim();
    return WeatherCondition(
      kind: kind,
      text: text == null || text.isEmpty ? _descriptionFromCode(code, kind) : text,
      code: code,
    );
  }

  static WeatherKind _kindFromCode(int code) {
    if (code == 0 || code == 1) return WeatherKind.clear;
    if (code == 45 || code == 48) return WeatherKind.fog;
    if ({51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82}.contains(code)) {
      return WeatherKind.rain;
    }
    if ({71, 73, 75, 77, 85, 86}.contains(code)) return WeatherKind.snow;
    if ({95, 96, 99}.contains(code)) return WeatherKind.storm;
    return WeatherKind.cloudy;
  }

  static String _descriptionFromCode(int code, WeatherKind kind) {
    return switch (code) {
      0 => 'آسمان صاف',
      1 => 'عمدتاً صاف',
      2 => 'نیمه‌ابری',
      3 => 'ابری',
      45 || 48 => 'مه‌آلود',
      51 => 'نم‌نم باران خفیف',
      53 => 'نم‌نم باران',
      55 => 'نم‌نم باران شدید',
      56 || 57 => 'باران یخ‌زن',
      61 => 'باران خفیف',
      63 => 'باران',
      65 => 'باران شدید',
      66 || 67 => 'باران یخ‌زن',
      71 => 'برف خفیف',
      73 => 'بارش برف',
      75 => 'برف شدید',
      77 => 'دانه‌های برف',
      80 => 'رگبار خفیف',
      81 => 'رگبار',
      82 => 'رگبار شدید',
      85 => 'رگبار برف خفیف',
      86 => 'رگبار برف شدید',
      95 => 'رعدوبرق',
      96 || 99 => 'رعدوبرق همراه تگرگ',
      _ => _fallbackText(kind),
    };
  }

  static String _fallbackText(WeatherKind kind) => switch (kind) {
        WeatherKind.clear => 'صاف',
        WeatherKind.cloudy => 'ابری',
        WeatherKind.rain => 'بارانی',
        WeatherKind.snow => 'برفی',
        WeatherKind.storm => 'طوفانی',
        WeatherKind.fog => 'مه‌آلود',
      };
}
