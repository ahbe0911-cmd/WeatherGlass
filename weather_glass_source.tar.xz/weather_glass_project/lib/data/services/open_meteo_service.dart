import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../core/config/weather_config.dart';
import '../models/location_data.dart';

class WeatherServiceException implements Exception {
  const WeatherServiceException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

/// Client for the Open-Meteo Forecast API. No API key or account is required
/// for eligible non-commercial usage.
class OpenMeteoService {
  OpenMeteoService({required http.Client client}) : _client = client;

  final http.Client _client;

  static Uri buildForecastUri(Coordinates coordinates) {
    return Uri.https(WeatherConfig.apiHost, WeatherConfig.forecastPath, {
      'latitude': coordinates.latitude.toStringAsFixed(6),
      'longitude': coordinates.longitude.toStringAsFixed(6),
      'current': [
        'temperature_2m',
        'relative_humidity_2m',
        'apparent_temperature',
        'is_day',
        'weather_code',
        'wind_speed_10m',
      ].join(','),
      'hourly': [
        'temperature_2m',
        'relative_humidity_2m',
        'apparent_temperature',
        'precipitation_probability',
        'weather_code',
        'is_day',
        'wind_speed_10m',
        'uv_index',
      ].join(','),
      'daily': [
        'weather_code',
        'temperature_2m_max',
        'temperature_2m_min',
        'sunrise',
        'sunset',
        'uv_index_max',
        'precipitation_probability_max',
        'wind_speed_10m_max',
      ].join(','),
      'timezone': 'auto',
      'forecast_days': WeatherConfig.forecastDays.toString(),
      'forecast_hours': WeatherConfig.forecastHours.toString(),
      'past_hours': '0',
      'temperature_unit': 'celsius',
      'wind_speed_unit': 'kmh',
      'timeformat': 'iso8601',
    });
  }

  Future<Map<String, dynamic>> fetchForecast(Coordinates coordinates) async {
    try {
      final response = await _client
          .get(buildForecastUri(coordinates))
          .timeout(const Duration(seconds: 20));

      Map<String, dynamic> decoded;
      try {
        final body = jsonDecode(response.body);
        if (body is! Map<String, dynamic>) {
          throw const WeatherServiceException('پاسخ سرویس هواشناسی قابل خواندن نیست.');
        }
        decoded = body;
      } on FormatException {
        throw const WeatherServiceException('پاسخ سرویس هواشناسی معتبر نیست.');
      }

      if (response.statusCode != 200) {
        final error = decoded['reason'] as String? ??
            decoded['error'] as String? ??
            'سرویس هواشناسی موقتاً در دسترس نیست.';
        throw WeatherServiceException(error, statusCode: response.statusCode);
      }
      if (decoded['current'] is! Map<String, dynamic> ||
          decoded['hourly'] is! Map<String, dynamic> ||
          decoded['daily'] is! Map<String, dynamic>) {
        throw const WeatherServiceException('اطلاعات دریافتی ناقص است.');
      }
      return decoded;
    } on TimeoutException {
      throw const WeatherServiceException('زمان اتصال به سرویس هواشناسی به پایان رسید.');
    } on http.ClientException {
      throw const WeatherServiceException('اتصال اینترنت برقرار نیست.');
    }
  }
}
