import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/config/weather_config.dart';
import '../models/location_data.dart';

class LocationService {
  LocationService(this._preferences);

  final SharedPreferences _preferences;

  static const _latKey = 'saved_latitude';
  static const _lonKey = 'saved_longitude';
  static const _onboardingKey = 'location_onboarding_complete';
  static const _permissionKey = 'location_permission_state';

  Future<LocationResult> resolveLocation() async {
    final saved = _readSavedCoordinates();
    final onboardingComplete = _preferences.getBool(_onboardingKey) ?? false;

    // Existing coordinates are always usable. Permission checks never trigger
    // a system dialog, so subsequent launches cannot repeatedly ask the user.
    if (saved != null) {
      final permission = await Geolocator.checkPermission();
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      var issue = LocationIssue.none;
      if (permission == LocationPermission.deniedForever) {
        issue = LocationIssue.permissionDeniedForever;
      } else if (permission == LocationPermission.denied) {
        issue = LocationIssue.permissionDenied;
      } else if (!serviceEnabled) {
        issue = LocationIssue.gpsDisabled;
      }

      if (_hasLocationPermission(permission) && serviceEnabled) {
        try {
          final position = await _getCurrentPosition();
          final distance = Geolocator.distanceBetween(
            saved.latitude,
            saved.longitude,
            position.latitude,
            position.longitude,
          );
          if (distance >= WeatherConfig.significantMoveMeters) {
            final updated = Coordinates(
              latitude: position.latitude,
              longitude: position.longitude,
            );
            await _saveCoordinates(updated);
            return LocationResult(coordinates: updated);
          }
        } catch (_) {
          // A location timeout should not prevent weather loading from the
          // last known coordinates.
        }
      }
      return LocationResult(coordinates: saved, issue: issue);
    }

    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Keep onboarding incomplete so the first successful retry can continue.
      return const LocationResult(coordinates: null, issue: LocationIssue.gpsDisabled);
    }

    var permission = await Geolocator.checkPermission();
    if (!onboardingComplete && permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    await _preferences.setString(_permissionKey, permission.name);

    if (permission == LocationPermission.deniedForever) {
      await _preferences.setBool(_onboardingKey, true);
      return const LocationResult(
        coordinates: null,
        issue: LocationIssue.permissionDeniedForever,
      );
    }
    if (permission == LocationPermission.denied) {
      await _preferences.setBool(_onboardingKey, true);
      return const LocationResult(
        coordinates: null,
        issue: LocationIssue.permissionDenied,
      );
    }
    if (!_hasLocationPermission(permission)) {
      return const LocationResult(coordinates: null, issue: LocationIssue.unavailable);
    }

    try {
      final position = await _getCurrentPosition();
      final coordinates = Coordinates(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      await _saveCoordinates(coordinates);
      await _preferences.setBool(_onboardingKey, true);
      await _preferences.setString(_permissionKey, permission.name);
      return LocationResult(coordinates: coordinates);
    } catch (_) {
      return const LocationResult(coordinates: null, issue: LocationIssue.unavailable);
    }
  }

  Future<void> openLocationSettings() async {
    await Geolocator.openLocationSettings();
  }

  Future<void> openAppSettings() async {
    await Geolocator.openAppSettings();
  }

  Coordinates? _readSavedCoordinates() {
    final lat = _preferences.getDouble(_latKey);
    final lon = _preferences.getDouble(_lonKey);
    if (lat == null || lon == null) return null;
    return Coordinates(latitude: lat, longitude: lon);
  }

  Future<void> _saveCoordinates(Coordinates coordinates) async {
    await _preferences.setDouble(_latKey, coordinates.latitude);
    await _preferences.setDouble(_lonKey, coordinates.longitude);
  }

  Future<Position> _getCurrentPosition() {
    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 14),
      ),
    );
  }

  bool _hasLocationPermission(LocationPermission permission) {
    return permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always;
  }
}
