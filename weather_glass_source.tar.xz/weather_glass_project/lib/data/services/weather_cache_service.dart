import 'dart:convert';

import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/location_data.dart';

class WeatherCacheService {
  static const _jsonKey = 'weather_cache_open_meteo_json_v1';
  static const _latKey = 'weather_cache_latitude';
  static const _lonKey = 'weather_cache_longitude';

  static Future<void> save(
    SharedPreferences preferences,
    Map<String, dynamic> payload,
    Coordinates coordinates,
  ) async {
    await preferences.setString(_jsonKey, jsonEncode(payload));
    await preferences.setDouble(_latKey, coordinates.latitude);
    await preferences.setDouble(_lonKey, coordinates.longitude);
  }

  static Map<String, dynamic>? readFor(
    SharedPreferences preferences,
    Coordinates coordinates,
  ) {
    final raw = preferences.getString(_jsonKey);
    final lat = preferences.getDouble(_latKey);
    final lon = preferences.getDouble(_lonKey);
    if (raw == null || lat == null || lon == null) return null;

    final distance = Geolocator.distanceBetween(
      lat,
      lon,
      coordinates.latitude,
      coordinates.longitude,
    );
    if (distance > 5000) return null;

    try {
      final decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : null;
    } on FormatException {
      return null;
    }
  }
}
