import 'dart:convert';
import 'dart:ui';

import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

import '../models/location_data.dart';
import 'open_meteo_service.dart';
import 'weather_cache_service.dart';

const weatherBackgroundTaskName = 'weatherGlassPeriodicRefresh';

@pragma('vm:entry-point')
void weatherBackgroundDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    DartPluginRegistrant.ensureInitialized();

    if (task != weatherBackgroundTaskName) return true;

    final preferences = await SharedPreferences.getInstance();
    final latitude = preferences.getDouble('saved_latitude');
    final longitude = preferences.getDouble('saved_longitude');
    if (latitude == null || longitude == null) return true;

    final coordinates = Coordinates(latitude: latitude, longitude: longitude);
    final client = http.Client();
    try {
      final response = await client
          .get(OpenMeteoService.buildForecastUri(coordinates))
          .timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) return false;
      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return false;
      await WeatherCacheService.save(preferences, decoded, coordinates);
      return true;
    } catch (_) {
      return false;
    } finally {
      client.close();
    }
  });
}

Future<void> configureWeatherBackgroundRefresh() async {
  await Workmanager().initialize(weatherBackgroundDispatcher);
  await Workmanager().registerPeriodicTask(
    'weather-glass-hourly-refresh',
    weatherBackgroundTaskName,
    frequency: const Duration(hours: 1),
    constraints: Constraints(networkType: NetworkType.connected),
  );
}
