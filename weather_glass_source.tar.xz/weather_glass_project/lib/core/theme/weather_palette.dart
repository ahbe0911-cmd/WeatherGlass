import 'package:flutter/material.dart';

import '../../data/models/weather_condition.dart';

enum DayPhase { dawn, day, dusk, night }

class WeatherPalette {
  const WeatherPalette({required this.top, required this.bottom, required this.accent});

  final Color top;
  final Color bottom;
  final Color accent;

  factory WeatherPalette.from(
    WeatherKind kind,
    bool isDay, {
    String? localtime,
    String? sunrise,
    String? sunset,
  }) {
    final phase = _resolvePhase(
      isDay: isDay,
      localtime: localtime,
      sunrise: sunrise,
      sunset: sunset,
    );

    if (phase == DayPhase.dawn) {
      return const WeatherPalette(
        top: Color(0xFF4D527D),
        bottom: Color(0xFFE49B83),
        accent: Color(0xFFFFD7A1),
      );
    }
    if (phase == DayPhase.dusk) {
      return const WeatherPalette(
        top: Color(0xFF4C416D),
        bottom: Color(0xFFD77F72),
        accent: Color(0xFFFFD19A),
      );
    }
    if (phase == DayPhase.night) {
      return const WeatherPalette(
        top: Color(0xFF101B3D),
        bottom: Color(0xFF263B61),
        accent: Color(0xFFB7D7FF),
      );
    }

    return switch (kind) {
      WeatherKind.clear => const WeatherPalette(
          top: Color(0xFF1767A8), bottom: Color(0xFF5AA8D7), accent: Color(0xFFFFD36E)),
      WeatherKind.cloudy => const WeatherPalette(
          top: Color(0xFF3F617F), bottom: Color(0xFF829EB2), accent: Color(0xFFE1EDF5)),
      WeatherKind.rain => const WeatherPalette(
          top: Color(0xFF263F5D), bottom: Color(0xFF54738D), accent: Color(0xFF9BD8F5)),
      WeatherKind.snow => const WeatherPalette(
          top: Color(0xFF66869D), bottom: Color(0xFFB4C9D7), accent: Color(0xFFE8F7FF)),
      WeatherKind.storm => const WeatherPalette(
          top: Color(0xFF1D2946), bottom: Color(0xFF46536E), accent: Color(0xFFFFD166)),
      WeatherKind.fog => const WeatherPalette(
          top: Color(0xFF596B78), bottom: Color(0xFF9AAAB1), accent: Color(0xFFE3EAEC)),
    };
  }

  static DayPhase _resolvePhase({
    required bool isDay,
    String? localtime,
    String? sunrise,
    String? sunset,
  }) {
    final localParts = localtime?.replaceAll('T', ' ').split(' ');
    if (localParts == null || localParts.length < 2) {
      return isDay ? DayPhase.day : DayPhase.night;
    }
    final clock = localParts[1].split(':');
    if (clock.length < 2) return isDay ? DayPhase.day : DayPhase.night;
    final hour = int.tryParse(clock[0]);
    final minute = int.tryParse(clock[1]);
    if (hour == null || minute == null) return isDay ? DayPhase.day : DayPhase.night;
    final nowMinutes = hour * 60 + minute;
    final sunriseMinutes = _parseTwelveHourClock(sunrise);
    final sunsetMinutes = _parseTwelveHourClock(sunset);
    if (sunriseMinutes == null || sunsetMinutes == null) {
      return isDay ? DayPhase.day : DayPhase.night;
    }

    if (nowMinutes >= sunriseMinutes - 25 && nowMinutes <= sunriseMinutes + 45) {
      return DayPhase.dawn;
    }
    if (nowMinutes >= sunsetMinutes - 45 && nowMinutes <= sunsetMinutes + 35) {
      return DayPhase.dusk;
    }
    if (nowMinutes > sunriseMinutes + 45 && nowMinutes < sunsetMinutes - 45) {
      return DayPhase.day;
    }
    return DayPhase.night;
  }

  static int? _parseTwelveHourClock(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final parts = value.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return null;
    final time = parts.first.split(':');
    if (time.length < 2) return null;
    var hour = int.tryParse(time[0]);
    final minute = int.tryParse(time[1]);
    if (hour == null || minute == null || hour < 0 || hour > 23 || minute > 59) return null;
    final suffix = parts.length > 1 ? parts[1].toUpperCase() : '';
    if (suffix == 'PM' && hour != 12) hour += 12;
    if (suffix == 'AM' && hour == 12) hour = 0;
    return hour * 60 + minute;
  }
}
