/// Open-Meteo provides a public forecast endpoint that does not require an API
/// key for non-commercial use. See https://open-meteo.com/en/terms.
abstract final class WeatherConfig {
  static const String apiHost = 'api.open-meteo.com';
  static const String forecastPath = '/v1/forecast';
  static const int forecastDays = 7;
  static const int forecastHours = 48;
  static const double significantMoveMeters = 5000;
}
