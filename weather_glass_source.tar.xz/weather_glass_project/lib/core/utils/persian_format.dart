import 'package:intl/intl.dart';

String toPersianDigits(Object value) {
  const latin = '0123456789';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  var result = value.toString();
  for (var i = 0; i < latin.length; i++) {
    result = result.replaceAll(latin[i], persian[i]);
  }
  return result;
}

String temperatureText(num value) => '${toPersianDigits(value.round())}°';

String localHourText(String apiDateTime) {
  final normalized = apiDateTime.replaceAll('T', ' ');
  final parts = normalized.split(' ');
  if (parts.length < 2 || parts[1].length < 5) return '--:--';
  return toPersianDigits(parts[1].substring(0, 5));
}

String weekdayText(DateTime date) {
  return toPersianDigits(DateFormat('EEEE', 'fa_IR').format(date));
}

String shortDateText(DateTime date) {
  return toPersianDigits(DateFormat('d MMM', 'fa_IR').format(date));
}
