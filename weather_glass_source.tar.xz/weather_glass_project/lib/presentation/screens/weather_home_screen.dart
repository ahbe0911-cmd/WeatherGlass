import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/weather_palette.dart';
import '../../core/utils/persian_format.dart';
import '../../data/models/location_data.dart';
import '../../data/models/weather_data.dart';
import '../providers/weather_controller.dart';
import '../widgets/glass_card.dart';
import '../widgets/weather_animation.dart';

class WeatherHomeScreen extends ConsumerWidget {
  const WeatherHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncState = ref.watch(weatherControllerProvider);

    return asyncState.when(
      loading: () => const _LoadingScreen(),
      error: (error, stack) => _ErrorScreen(message: error.toString()),
      data: (state) {
        if (state.weather == null) return _SetupScreen(state: state);
        return _WeatherDashboard(state: state);
      },
    );
  }
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF153D68), Color(0xFF162744)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(width: 34, height: 34, child: CircularProgressIndicator(strokeWidth: 2.5)),
              SizedBox(height: 18),
              Text('در حال دریافت وضعیت هوا...'),
            ],
          ),
        ),
      ),
    );
  }
}

class _ErrorScreen extends StatelessWidget {
  const _ErrorScreen({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _FullBackground(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline_rounded, size: 52),
                const SizedBox(height: 16),
                const Text('مشکلی پیش آمده است', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(message, textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SetupScreen extends ConsumerWidget {
  const _SetupScreen({required this.state});

  final WeatherScreenState state;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.read(weatherControllerProvider.notifier);
    String title;
    String body;
    String action;
    Future<void> Function() onPressed;
    var refreshAfterSettings = false;

    if (state.coordinates != null) {
      title = 'دریافت اطلاعات هواشناسی';
      body = state.message ?? 'ارتباط با سرویس هواشناسی برقرار نشد.';
      action = 'تلاش دوباره';
      onPressed = controller.refresh;
    } else {
      switch (state.locationIssue) {
        case LocationIssue.gpsDisabled:
          title = 'موقعیت‌یاب خاموش است';
          body = 'برای ثبت موقعیت اولیه، GPS دستگاه را روشن کنید. برنامه پس از ذخیره مختصات، در اجراهای بعدی از همان موقعیت استفاده می‌کند.';
          action = 'باز کردن تنظیمات مکان';
          onPressed = controller.openLocationSettings;
          refreshAfterSettings = true;
          break;
        case LocationIssue.permissionDenied:
          title = 'دسترسی مکان داده نشده است';
          body = 'برای استفاده از موقعیت فعلی، دسترسی مکان را از تنظیمات برنامه فعال کنید. برنامه در اجراهای بعدی دوباره پنجره مجوز را نمایش نمی‌دهد.';
          action = 'تنظیمات برنامه';
          onPressed = controller.openAppSettings;
          refreshAfterSettings = true;
          break;
        case LocationIssue.permissionDeniedForever:
          title = 'دسترسی مکان مسدود شده است';
          body = 'دسترسی مکان برای برنامه مسدود شده است. آن را از تنظیمات اندروید فعال کنید.';
          action = 'تنظیمات برنامه';
          onPressed = controller.openAppSettings;
          refreshAfterSettings = true;
          break;
        case LocationIssue.unavailable:
        case LocationIssue.none:
          title = 'موقعیت فعلی دریافت نشد';
          body = state.message ?? 'اتصال GPS را بررسی کنید و دوباره تلاش کنید.';
          action = 'تلاش دوباره';
          onPressed = controller.refresh;
          break;
      }
    }

    return Scaffold(
      body: _FullBackground(
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: GlassCard(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.location_on_rounded, size: 54),
                    const SizedBox(height: 16),
                    Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    Text(body, textAlign: TextAlign.center, style: const TextStyle(height: 1.8)),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () async {
                          await onPressed();
                          if (refreshAfterSettings) await controller.refresh();
                        },
                        icon: const Icon(Icons.settings_rounded),
                        label: Text(action),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _WeatherDashboard extends ConsumerWidget {
  const _WeatherDashboard({required this.state});

  final WeatherScreenState state;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weather = state.weather!;
    final current = weather.current;
    final firstForecastDay = weather.daily.isNotEmpty ? weather.daily.first : null;
    final palette = WeatherPalette.from(
      current.condition.kind,
      current.isDay,
      localtime: weather.location.localtime,
      sunrise: firstForecastDay?.sunrise,
      sunset: firstForecastDay?.sunset,
    );

    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [palette.top, palette.bottom],
          ),
        ),
        child: Stack(
          children: [
            const _AmbientOrbs(),
            SafeArea(
              child: RefreshIndicator(
                color: palette.top,
                onRefresh: () => ref.read(weatherControllerProvider.notifier).refresh(),
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 36),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _Header(weather: weather, isStale: state.isStale),
                      if (state.locationIssue != LocationIssue.none) ...[
                        const SizedBox(height: 14),
                        _LocationNotice(issue: state.locationIssue),
                      ],
                      if (state.message != null && state.isStale) ...[
                        const SizedBox(height: 10),
                        Text(state.message!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.white70)),
                      ],
                      const SizedBox(height: 20),
                      _CurrentWeatherCard(weather: weather),
                      const SizedBox(height: 16),
                      _MetricsRow(current: current),
                      const SizedBox(height: 24),
                      const _SectionTitle(title: 'پیش‌بینی ساعتی', subtitle: '۴۸ ساعت آینده'),
                      const SizedBox(height: 12),
                      _HourlyForecastCard(hours: weather.hourly),
                      const SizedBox(height: 24),
                      const _SectionTitle(title: 'پیش‌بینی هفتگی', subtitle: '۷ روز آینده'),
                      const SizedBox(height: 12),
                      _WeeklyForecastCard(days: weather.daily),
                      const SizedBox(height: 14),
                      _SunTimesCard(day: weather.daily.isNotEmpty ? weather.daily.first : null),
                      const SizedBox(height: 16),
                      const Text(
                        'اطلاعات پیش‌بینی ممکن است با تغییر شرایط جوی به‌روزرسانی شود.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white60, fontSize: 11),
                      ),
                      TextButton(
                        onPressed: () => launchUrl(
                          Uri.parse('https://open-meteo.com/'),
                          mode: LaunchMode.externalApplication,
                        ),
                        child: const Text(
                          'منبع داده‌های هواشناسی: Open-Meteo.com',
                          style: TextStyle(color: Colors.white70, fontSize: 11),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends ConsumerWidget {
  const _Header({required this.weather, required this.isStale});

  final WeatherData weather;
  final bool isStale;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final location = weather.location;
    final place = [location.name, location.region].where((part) => part.trim().isNotEmpty).join('، ');
    return Row(
      children: [
        const Icon(Icons.location_on_outlined, size: 22),
        const SizedBox(width: 7),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(place.isEmpty ? 'موقعیت فعلی' : place, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              if (location.localtime.isNotEmpty)
                Text(toPersianDigits(location.localtime), style: const TextStyle(fontSize: 11, color: Colors.white70)),
            ],
          ),
        ),
        if (isStale) const Padding(
          padding: EdgeInsetsDirectional.only(end: 8),
          child: Icon(Icons.cloud_off_rounded, size: 18, color: Colors.white70),
        ),
        IconButton(
          tooltip: 'به‌روزرسانی',
          onPressed: () => ref.read(weatherControllerProvider.notifier).refresh(),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
    );
  }
}

class _CurrentWeatherCard extends StatelessWidget {
  const _CurrentWeatherCard({required this.weather});

  final WeatherData weather;

  @override
  Widget build(BuildContext context) {
    final current = weather.current;
    return GlassCard(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(current.condition.text, style: TextStyle(fontSize: 16, color: Colors.white.withValues(alpha: 0.9))),
                    const SizedBox(height: 4),
                    Text(temperatureText(current.temperatureC), style: const TextStyle(fontSize: 58, height: 1.15, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text('احساس واقعی ${temperatureText(current.feelsLikeC)}', style: const TextStyle(fontSize: 13, color: Colors.white70)),
                  ],
                ),
              ),
              WeatherAnimation(kind: current.condition.kind, isDay: current.isDay),
            ],
          ),
          const Divider(color: Colors.white24, height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _InlineValue(label: 'رطوبت', value: '${toPersianDigits(current.humidity)}٪'),
              _InlineValue(label: 'باد', value: '${toPersianDigits(current.windKph.round())} km/h'),
              _InlineValue(label: 'شاخص UV', value: toPersianDigits(current.uv.toStringAsFixed(1))),
            ],
          ),
        ],
      ),
    );
  }
}

class _InlineValue extends StatelessWidget {
  const _InlineValue({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70)),
      ],
    );
  }
}

class _MetricsRow extends StatelessWidget {
  const _MetricsRow({required this.current});

  final CurrentWeather current;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _MetricTile(icon: Icons.water_drop_outlined, title: 'رطوبت', value: '${toPersianDigits(current.humidity)}٪')),
        const SizedBox(width: 10),
        Expanded(child: _MetricTile(icon: Icons.air_rounded, title: 'سرعت باد', value: '${toPersianDigits(current.windKph.round())} کیلومتر')),
        const SizedBox(width: 10),
        Expanded(child: _MetricTile(icon: Icons.wb_sunny_outlined, title: 'UV', value: toPersianDigits(current.uv.toStringAsFixed(1)))),
      ],
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({required this.icon, required this.title, required this.value});

  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 13),
      child: Column(
        children: [
          Icon(icon, size: 21, color: Colors.white70),
          const SizedBox(height: 8),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          const SizedBox(height: 3),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.white70)),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
        Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.white70)),
      ],
    );
  }
}

class _HourlyForecastCard extends StatelessWidget {
  const _HourlyForecastCard({required this.hours});

  final List<HourlyForecast> hours;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: SizedBox(
        height: 124,
        child: hours.isEmpty
            ? const Center(child: Text('اطلاعات ساعتی موجود نیست'))
            : ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                itemCount: hours.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (context, index) {
                  final hour = hours[index];
                  return SizedBox(
                    width: 62,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(localHourText(hour.time), style: const TextStyle(fontSize: 11, color: Colors.white70)),
                        Icon(hour.condition.icon, size: 24, color: const Color(0xFFFFE3A0)),
                        Text(temperatureText(hour.temperatureC), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text('بارش ${toPersianDigits(hour.chanceOfRain)}٪', style: const TextStyle(fontSize: 9, color: Colors.white70)),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}

class _WeeklyForecastCard extends StatelessWidget {
  const _WeeklyForecastCard({required this.days});

  final List<DailyForecast> days;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        children: [
          for (var index = 0; index < days.length; index++) ...[
            _DailyRow(day: days[index], isToday: index == 0),
            if (index != days.length - 1) const Divider(color: Colors.white12, height: 1),
          ],
        ],
      ),
    );
  }
}

class _DailyRow extends StatelessWidget {
  const _DailyRow({required this.day, required this.isToday});

  final DailyForecast day;
  final bool isToday;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          SizedBox(
            width: 76,
            child: Text(isToday ? 'امروز' : weekdayText(day.date), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          ),
          Icon(day.condition.icon, size: 23, color: const Color(0xFFFFE2A0)),
          const SizedBox(width: 9),
          Expanded(
            child: Text(day.condition.text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ),
          Text(temperatureText(day.maxTemperatureC), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
          const SizedBox(width: 12),
          Text(temperatureText(day.minTemperatureC), style: const TextStyle(fontSize: 13, color: Colors.white70)),
          const SizedBox(width: 10),
          Text('${toPersianDigits(day.chanceOfRain)}٪', style: const TextStyle(fontSize: 10, color: Colors.lightBlueAccent)),
        ],
      ),
    );
  }
}

class _SunTimesCard extends StatelessWidget {
  const _SunTimesCard({required this.day});

  final DailyForecast? day;

  @override
  Widget build(BuildContext context) {
    if (day == null) return const SizedBox.shrink();
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _SunTime(icon: Icons.wb_twilight_rounded, label: 'طلوع خورشید', value: day!.sunrise),
          _SunTime(icon: Icons.nights_stay_outlined, label: 'غروب خورشید', value: day!.sunset),
        ],
      ),
    );
  }
}

class _SunTime extends StatelessWidget {
  const _SunTime({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFFFFE0A0), size: 22),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 10, color: Colors.white70)),
            Text(toPersianDigits(value), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    );
  }
}

class _LocationNotice extends ConsumerWidget {
  const _LocationNotice({required this.issue});

  final LocationIssue issue;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final message = switch (issue) {
      LocationIssue.gpsDisabled => 'GPS خاموش است؛ از مختصات ذخیره‌شده استفاده می‌شود.',
      LocationIssue.permissionDenied => 'مجوز مکان غیرفعال است؛ از مختصات ذخیره‌شده استفاده می‌شود.',
      LocationIssue.permissionDeniedForever => 'مجوز مکان مسدود است؛ از مختصات ذخیره‌شده استفاده می‌شود.',
      LocationIssue.unavailable => 'موقعیت تازه دریافت نشد؛ از مختصات ذخیره‌شده استفاده می‌شود.',
      LocationIssue.none => '',
    };
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
      child: Row(
        children: [
          const Icon(Icons.info_outline_rounded, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(message, style: const TextStyle(fontSize: 11, height: 1.5))),
          TextButton(
            onPressed: () async {
              final controller = ref.read(weatherControllerProvider.notifier);
              if (issue == LocationIssue.gpsDisabled) {
                await controller.openLocationSettings();
              } else if (issue == LocationIssue.permissionDenied ||
                  issue == LocationIssue.permissionDeniedForever) {
                await controller.openAppSettings();
              }
              await controller.refresh();
            },
            child: const Text('تنظیمات', style: TextStyle(fontSize: 11)),
          ),
        ],
      ),
    );
  }
}

class _FullBackground extends StatelessWidget {
  const _FullBackground({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF173E66), Color(0xFF182A48)],
        ),
      ),
      child: Stack(children: [const _AmbientOrbs(), child]),
    );
  }
}

class _AmbientOrbs extends StatelessWidget {
  const _AmbientOrbs();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Stack(
        children: [
          Positioned(
            top: -95,
            right: -65,
            child: Container(
              width: 230,
              height: 230,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.045),
              ),
            ),
          ),
          Positioned(
            bottom: 100,
            left: -110,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.lightBlueAccent.withValues(alpha: 0.045),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
