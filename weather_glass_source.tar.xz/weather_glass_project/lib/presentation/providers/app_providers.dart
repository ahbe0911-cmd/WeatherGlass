import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/services/location_service.dart';
import '../../data/services/open_meteo_service.dart';

final sharedPreferencesProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError('SharedPreferences must be overridden in main().');
});

final locationServiceProvider = Provider<LocationService>((ref) {
  return LocationService(ref.watch(sharedPreferencesProvider));
});

final openMeteoServiceProvider = Provider<OpenMeteoService>((ref) {
  final client = http.Client();
  ref.onDispose(client.close);
  return OpenMeteoService(client: client);
});
