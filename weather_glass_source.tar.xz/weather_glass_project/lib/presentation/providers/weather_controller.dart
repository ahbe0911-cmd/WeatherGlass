import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/location_data.dart';
import '../../data/models/weather_data.dart';
import '../../data/services/weather_cache_service.dart';
import '../../data/services/open_meteo_service.dart';
import 'app_providers.dart';

class WeatherScreenState {
  const WeatherScreenState({
    this.weather,
    this.coordinates,
    this.locationIssue = LocationIssue.none,
    this.isStale = false,
    this.message,
  });

  final WeatherData? weather;
  final Coordinates? coordinates;
  final LocationIssue locationIssue;
  final bool isStale;
  final String? message;
}

final weatherControllerProvider =
    AsyncNotifierProvider<WeatherController, WeatherScreenState>(WeatherController.new);

class WeatherController extends AsyncNotifier<WeatherScreenState> {
  @override
  Future<WeatherScreenState> build() => _load();

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_load);
  }

  Future<void> openLocationSettings() async {
    await ref.read(locationServiceProvider).openLocationSettings();
  }

  Future<void> openAppSettings() async {
    await ref.read(locationServiceProvider).openAppSettings();
  }

  Future<WeatherScreenState> _load() async {
    final preferences = ref.read(sharedPreferencesProvider);
    LocationResult locationResult;
    try {
      locationResult = await ref.read(locationServiceProvider).resolveLocation();
    } catch (_) {
      return const WeatherScreenState(
        locationIssue: LocationIssue.unavailable,
        message: 'سرویس مکان‌یابی پاسخ نداد. تنظیمات GPS را بررسی کنید و دوباره تلاش کنید.',
      );
    }
    final coordinates = locationResult.coordinates;

    if (coordinates == null) {
      return WeatherScreenState(
        locationIssue: locationResult.issue,
        message: _locationMessage(locationResult.issue),
      );
    }

    try {
      final payload = await ref.read(openMeteoServiceProvider).fetchForecast(coordinates);
      await WeatherCacheService.save(preferences, payload, coordinates);
      return WeatherScreenState(
        weather: WeatherData.fromJson(payload),
        coordinates: coordinates,
        locationIssue: locationResult.issue,
      );
    } catch (error) {
      final cached = WeatherCacheService.readFor(preferences, coordinates);
      if (cached != null) {
        return WeatherScreenState(
          weather: WeatherData.fromJson(cached),
          coordinates: coordinates,
          locationIssue: locationResult.issue,
          isStale: true,
          message: 'اتصال برقرار نشد؛ آخرین اطلاعات ذخیره‌شده نمایش داده می‌شود.',
        );
      }
      return WeatherScreenState(
        coordinates: coordinates,
        locationIssue: locationResult.issue,
        message: error is WeatherServiceException ? error.message : 'خطای غیرمنتظره در دریافت اطلاعات هواشناسی.',
      );
    }
  }

  String _locationMessage(LocationIssue issue) => switch (issue) {
        LocationIssue.gpsDisabled => 'برای تعیین موقعیت اولیه، سرویس مکان‌یابی دستگاه را روشن کنید.',
        LocationIssue.permissionDenied => 'دسترسی موقعیت مکانی داده نشده است.',
        LocationIssue.permissionDeniedForever => 'دسترسی موقعیت مکانی مسدود شده است؛ آن را از تنظیمات برنامه فعال کنید.',
        LocationIssue.unavailable => 'موقعیت فعلی دریافت نشد. دوباره تلاش کنید.',
        LocationIssue.none => 'موقعیت مکانی در دسترس نیست.',
      };
}
