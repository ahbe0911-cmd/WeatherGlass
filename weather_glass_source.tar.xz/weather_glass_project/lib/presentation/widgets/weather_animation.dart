import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../data/models/weather_condition.dart';

class WeatherAnimation extends StatefulWidget {
  const WeatherAnimation({super.key, required this.kind, required this.isDay});

  final WeatherKind kind;
  final bool isDay;

  @override
  State<WeatherAnimation> createState() => _WeatherAnimationState();
}

class _WeatherAnimationState extends State<WeatherAnimation>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 7),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String get _asset {
    if (widget.kind == WeatherKind.clear && !widget.isDay) {
      return 'assets/animations/night.json';
    }
    return switch (widget.kind) {
      WeatherKind.clear => 'assets/animations/sunny.json',
      WeatherKind.cloudy => 'assets/animations/cloudy.json',
      WeatherKind.rain => 'assets/animations/rainy.json',
      WeatherKind.snow => 'assets/animations/snowy.json',
      WeatherKind.storm => 'assets/animations/stormy.json',
      WeatherKind.fog => 'assets/animations/foggy.json',
    };
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 174,
      height: 174,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Lottie.asset(_asset, repeat: true, fit: BoxFit.contain),
          IgnorePointer(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) => CustomPaint(
                painter: _WeatherParticlesPainter(
                  progress: _controller.value,
                  kind: widget.kind,
                  accent: widget.kind == WeatherKind.clear
                      ? const Color(0xFFFFE19A)
                      : const Color(0xFFD9F1FF),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WeatherParticlesPainter extends CustomPainter {
  const _WeatherParticlesPainter({
    required this.progress,
    required this.kind,
    required this.accent,
  });

  final double progress;
  final WeatherKind kind;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.stroke;
    final random = math.Random(19);

    switch (kind) {
      case WeatherKind.rain:
      case WeatherKind.storm:
        paint
          ..color = accent.withValues(alpha: 0.68)
          ..strokeWidth = 2.2
          ..strokeCap = StrokeCap.round;
        for (var i = 0; i < 13; i++) {
          final x = 20 + random.nextDouble() * (size.width - 40);
          final y = ((i * 31.0 + progress * size.height * 1.8) % (size.height + 30)) - 15;
          canvas.drawLine(Offset(x, y), Offset(x - 4, y + 13), paint);
        }
        if (kind == WeatherKind.storm && progress > 0.48 && progress < 0.58) {
          final flash = Paint()..color = const Color(0xFFFFE27A).withValues(alpha: 0.8);
          final path = Path()
            ..moveTo(size.width * 0.64, size.height * 0.53)
            ..lineTo(size.width * 0.52, size.height * 0.72)
            ..lineTo(size.width * 0.61, size.height * 0.72)
            ..lineTo(size.width * 0.55, size.height * 0.9)
            ..lineTo(size.width * 0.76, size.height * 0.64)
            ..lineTo(size.width * 0.66, size.height * 0.64)
            ..close();
          canvas.drawPath(path, flash);
        }
        break;
      case WeatherKind.snow:
        paint
          ..style = PaintingStyle.fill
          ..color = accent.withValues(alpha: 0.8);
        for (var i = 0; i < 15; i++) {
          final x = 18 + random.nextDouble() * (size.width - 36);
          final y = ((i * 37.0 + progress * size.height * 1.1) % (size.height + 20)) - 10;
          canvas.drawCircle(Offset(x, y), 2 + (i % 3) * 0.6, paint);
        }
        break;
      case WeatherKind.clear:
        paint
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = accent.withValues(alpha: 0.65);
        for (var i = 0; i < 5; i++) {
          final angle = progress * math.pi * 2 + i * math.pi * 2 / 5;
          final center = Offset(size.width / 2, size.height / 2);
          final start = center + Offset(math.cos(angle) * 66, math.sin(angle) * 66);
          final end = center + Offset(math.cos(angle) * 78, math.sin(angle) * 78);
          canvas.drawLine(start, end, paint);
        }
        break;
      case WeatherKind.cloudy:
        paint
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = accent.withValues(alpha: 0.34);
        final drift = math.sin(progress * math.pi * 2) * 5;
        canvas.drawArc(
          Rect.fromCenter(center: Offset(size.width * 0.5 + drift, size.height * 0.53), width: 145, height: 75),
          math.pi,
          math.pi,
          false,
          paint,
        );
        break;
      case WeatherKind.fog:
        paint
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round
          ..color = accent.withValues(alpha: 0.38);
        for (var i = 0; i < 4; i++) {
          final y = size.height * (0.62 + i * 0.075);
          final shift = math.sin(progress * math.pi * 2 + i) * 10;
          canvas.drawLine(
            Offset(size.width * 0.22 + shift, y),
            Offset(size.width * 0.78 + shift, y),
            paint,
          );
        }
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _WeatherParticlesPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.kind != kind;
}
