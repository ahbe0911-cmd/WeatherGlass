import 'package:flutter_test/flutter_test.dart';
import 'package:weather_glass/core/utils/persian_format.dart';
import 'package:weather_glass/data/models/weather_condition.dart';
import 'package:weather_glass/data/models/weather_data.dart';

void main() {
  group('Persian formatting', () {
    test('converts Latin digits to Persian digits', () {
      expect(toPersianDigits('21.5'), '۲۱.۵');
    });

    test('formats Open-Meteo ISO hour values', () {
      expect(localHourText('2026-11-09T18:00'), '۱۸:۰۰');
    });
  });

  group('WMO weather code mapping', () {
    test('maps rain codes to rain animation category', () {
      expect(WeatherCondition.fromCode(63).kind, WeatherKind.rain);
    });

    test('maps thunder codes to storm category', () {
      expect(WeatherCondition.fromCode(95).kind, WeatherKind.storm);
    });

    test('maps fog and snow codes', () {
      expect(WeatherCondition.fromCode(45).kind, WeatherKind.fog);
      expect(WeatherCondition.fromCode(73).kind, WeatherKind.snow);
    });
  });

  test('parses Open-Meteo current, hourly, and daily forecast payload', () {
    final weather = WeatherData.fromJson({
      'timezone': 'Asia/Tehran',
      'current': {
        'time': '2026-11-09T18:00',
        'temperature_2m': 18.5,
        'relative_humidity_2m': 42,
        'apparent_temperature': 17.2,
        'is_day': 0,
        'weather_code': 2,
        'wind_speed_10m': 12.4,
      },
      'hourly': {
        'time': ['2026-11-09T18:00', '2026-11-09T19:00'],
        'temperature_2m': [18.5, 17.0],
        'relative_humidity_2m': [42, 45],
        'apparent_temperature': [17.2, 16.0],
        'precipitation_probability': [10, 20],
        'weather_code': [2, 3],
        'is_day': [0, 0],
        'wind_speed_10m': [12.4, 10.0],
        'uv_index': [0.1, 0.0],
      },
      'daily': {
        'time': ['2026-11-09'],
        'weather_code': [2],
        'temperature_2m_max': [21.0],
        'temperature_2m_min': [12.0],
        'sunrise': ['2026-11-09T06:20'],
        'sunset': ['2026-11-09T17:10'],
        'uv_index_max': [4.2],
        'precipitation_probability_max': [20],
        'wind_speed_10m_max': [18.0],
      },
    });

    expect(weather.location.timezone, 'Asia/Tehran');
    expect(weather.current.temperatureC, 18.5);
    expect(weather.current.uv, 0.1);
    expect(weather.hourly, hasLength(2));
    expect(weather.daily, hasLength(1));
    expect(weather.daily.first.sunrise, '06:20');
  });
}
