#!/usr/bin/env bash
set -euo pipefail

# Generate the standard Android Gradle host files if this source package was
# extracted without the platform scaffold.
if [[ ! -d android ]]; then
  flutter create --platforms=android --org com.weatherglass --project-name weather_glass .
fi

mkdir -p android/app/src/main
cp tool/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

echo "Android platform scaffold is ready."
